<div
    <?php echo e($attributes->only(['data-for-component'])->merge(['class' => 'hidden-ids'])); ?>

>
</div>
<?php /**PATH D:\www\test_works\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/fields/hidden-ids.blade.php ENDPATH**/ ?>