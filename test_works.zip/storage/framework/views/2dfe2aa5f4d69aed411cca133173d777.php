<td <?php echo e($attributes); ?>>
    <?php echo $slot ?? ''; ?>

</td>
<?php /**PATH D:\www\test_works\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/components/table/td.blade.php ENDPATH**/ ?>