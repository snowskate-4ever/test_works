<?php echo $layout; ?>

<?php /**PATH D:\www\test_works\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/page.blade.php ENDPATH**/ ?>