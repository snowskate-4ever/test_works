<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e($data['title'] ?? (config('app.name') . ' - ' . __('Swagger'))); ?></title>

        <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@latest/swagger-ui.css">

        <style>
            html {
                box-sizing: border-box;
            }

            *, *:before, *:after {
                box-sizing: inherit;
            }

            body {
                margin: 0;
                background: #fafafa;
            }
        </style>

        <?php if(! empty($data['stylesheet'])): ?>
            <style><?php echo e(file_get_contents($data['stylesheet'])); ?></style>
        <?php endif; ?>
    </head>
    <body>
        <div id="swagger-ui"></div>

        <script src="https://unpkg.com/swagger-ui-dist@latest/swagger-ui-bundle.js"></script>
        <script src="https://unpkg.com/swagger-ui-dist@latest/swagger-ui-standalone-preset.js"></script>

        <script>
            window.onload = function () {
                window.ui = SwaggerUIBundle({
                    urls: [
                        <?php $__currentLoopData = $data['versions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version => $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            {
                                url: '<?php echo e(url("{$data['path']}/{$version}")); ?>',
                                name: '<?php echo e($version); ?>',
                            },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    "urls.primaryName": "<?php echo e($data['default']); ?>",
                    dom_id: '#swagger-ui',
                    deepLinking: true,
                    presets: [
                        SwaggerUIBundle.presets.apis,
                        SwaggerUIStandalonePreset
                    ],
                    layout: 'StandaloneLayout',
                    <?php if(!is_null($data["validator_url"])): ?>
                        validatorUrl: '<?php echo e($data["validator_url"]); ?>',
                    <?php endif; ?>
                    oauth2RedirectUrl: '<?php echo e(url("{$data['path']}/oauth2-redirect")); ?>',
                });

                ui.initOAuth({
                    clientId: '<?php echo e($data['oauth']['client_id']); ?>',
                    clientSecret: '<?php echo e($data['oauth']['client_secret']); ?>',
                });
            };
        </script>
    </body>
</html>
<?php /**PATH D:\www\test_works\vendor\nextapps\laravel-swagger-ui\src/../resources/views/index.blade.php ENDPATH**/ ?>