<?php echo $content; ?>

<?php /**PATH D:\www\test_works\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/components/flexible-render.blade.php ENDPATH**/ ?>