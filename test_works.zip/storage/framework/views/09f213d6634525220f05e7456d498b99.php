<th <?php echo e($attributes); ?>>
    <?php echo $slot ?? ''; ?>

</th>
<?php /**PATH D:\www\test_works\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/components/table/th.blade.php ENDPATH**/ ?>